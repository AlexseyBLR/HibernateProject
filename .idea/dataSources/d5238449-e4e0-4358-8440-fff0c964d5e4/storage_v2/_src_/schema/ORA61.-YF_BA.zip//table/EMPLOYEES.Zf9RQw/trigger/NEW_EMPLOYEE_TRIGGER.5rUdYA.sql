CREATE TRIGGER NEW_EMPLOYEE_TRIGGER
  BEFORE INSERT
  ON EMPLOYEES
  FOR EACH ROW
  begin  
   if inserting then 
      if :NEW."EMPLOYEE_ID" is null then 
         select EMPLOYEES_SEQ.nextval into :NEW."EMPLOYEE_ID" from dual; 
      end if; 
   end if; 
end;
/

