CREATE VIEW DEPT50 AS
  select EMPLOYEE_ID EMPNO,
          LAST_NAME EMPLOYEE,
          DEPARTMENT_ID DEPTNO
   from employees
   WHERE department_id =50
with check option
/

