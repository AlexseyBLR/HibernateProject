CREATE VIEW EMPLOYEES_VU AS
  select EMPLOYEE_ID,
          LAST_NAME EMPLOYEE,
          DEPARTMENT_ID
   from employees
/

